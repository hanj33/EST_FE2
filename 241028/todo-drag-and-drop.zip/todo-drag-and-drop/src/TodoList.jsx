import React, { useState } from 'react';
import './TodoList.css';
// 드래그 앤 드롭 할 일 목록 컴포넌트
const DragDropTodoList = () => {
    // 각 리스트의 상태를 관리하는 state
    // lists는 todo, inProgress, done 세 개의 리스트를 가지고 있는 객체
    // 각 리스트는 title(제목)과 items(할 일 항목 배열)을 가짐
    const [lists, setLists] = useState({
        todo: {
            title: '할 일',
            items: [
                { id: '1', text: 'React 공부하기' },
                { id: '2', text: '포트폴리오 만들기' },
                { id: '3', text: '이력서 작성하기' }
            ]
        },
        inProgress: {
            title: '진행 중',
            items: []
        },
        done: {
            title: '완료',
            items: []
        }
    });

    // 현재 드래그 중인 아이템의 정보를 저장하는 state
    // item(드래그 중인 할 일 객체)와 sourceListId(원래 있던 리스트의 ID)를 포함
    const [draggingItem, setDraggingItem] = useState(null);

    // 현재 드래그된 아이템이 위치한 리스트의 ID를 저장하는 state
    // 드래그 오버 효과를 주기 위해 사용
    const [dragOverList, setDragOverList] = useState(null);

    // 드래그가 시작될 때 호출되는 핸들러
    // e: 이벤트 객체
    // item: 드래그되는 할 일 객체
    // sourceListId: 드래그가 시작된 리스트의 ID
    const handleDragStart = (e, item, sourceListId) => {
        // 드래그 중인 아이템 정보를 state에 저장
        setDraggingItem({ item, sourceListId });
        // 드래그 중인 요소에 'dragging' 클래스를 추가하여 스타일 적용
        e.target.classList.add('dragging');
    };

    // 드래그가 끝날 때 호출되는 핸들러
    const handleDragEnd = (e) => {
        // 드래그가 끝난 요소에서 'dragging' 클래스 제거
        e.target.classList.remove('dragging');
        // 드래그 관련 state 초기화
        setDraggingItem(null);
        setDragOverList(null);
    };

    // 드래그 중인 아이템이 특정 영역 위에 있을 때 호출되는 핸들러
    const handleDragOver = (e, listId) => {
        // 기본 드래그 오버 동작 방지
        e.preventDefault();
        // 현재 드래그 오버 중인 리스트 ID 저장
        setDragOverList(listId);
    };


    // 아이템을 드롭했을 때 호출되는 핸들러
    const handleDrop = (targetListId) => {
        // 드래그 중인 아이템이 없으면 함수 종료
        if (!draggingItem) return;

        // 드래그 중인 아이템 정보 추출
        const { item, sourceListId } = draggingItem;

        // lists 상태 업데이트
        setLists(prev => {
            // 같은 리스트 내에서 드롭한 경우 상태 변경하지 않음
            if (sourceListId === targetListId) return prev;

            // 원본 리스트에서 드래그된 아이템 제거
            const sourceList = prev[sourceListId].items.filter(
                i => i.id !== item.id
            );

            // 대상 리스트에 드래그된 아이템 추가
            const targetList = [...prev[targetListId].items, item];

            // 새로운 상태 반환
            // 불변성을 지키면서 상태 업데이트
            return {
                ...prev,
                [sourceListId]: {
                    ...prev[sourceListId],
                    items: sourceList
                },
                [targetListId]: {
                    ...prev[targetListId],
                    items: targetList
                }
            };
        });

        // 드래그 오버 상태 초기화
        setDragOverList(null);
    };

    return (
        <article className="todo-container">
            <h1 className="todo-title">할 일 목록</h1>
            <div className="board-container">
                {/* 주어진 객체의 [key, value] 쌍의 배열을 반환합니다. */}
                {Object.entries(lists).map(([listId, list]) => (
                    <section
                        key={listId}
                        className={`board ${dragOverList === listId ? 'drag-over' : ''}`}
                        onDragOver={(e) => handleDragOver(e, listId)}
                        onDrop={() => handleDrop(listId)}
                    >
                        <h2 className="board-title">
                            {list.title}
                            <span className="item-count">
                                {list.items.length}
                            </span>
                        </h2>
                        <ul className="items-container">
                            {list.items.map((item) => (
                                <li
                                    key={item.id}
                                    className="todo-item"
                                    draggable
                                    onDragStart={(e) => handleDragStart(e, item, listId)}
                                    onDragEnd={handleDragEnd}
                                >
                                    {item.text}
                                </li>
                            ))}
                        </ul>
                    </section>
                ))}
            </div>
        </article>
    );
};

export default DragDropTodoList;