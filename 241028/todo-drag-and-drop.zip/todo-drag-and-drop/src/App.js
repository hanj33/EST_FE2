import DragDropTodoList from "./TodoList";

function App() {
  return (
    <DragDropTodoList />
  );
}
export default App;
